package com.safety_net.alerts;

import org.junit.jupiter.api.Test;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SafetyNetAlertsApplicationTests {

	@Test
	void contextLoads() {
	}

}
